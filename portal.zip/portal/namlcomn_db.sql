-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 29, 2018 at 07:19 PM
-- Server version: 5.7.20-0ubuntu0.16.04.1
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `namlcomn_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `mc_activeinvestments`
--

CREATE TABLE `mc_activeinvestments` (
  `investment_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mc_activeloans`
--

CREATE TABLE `mc_activeloans` (
  `loan_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mc_customers`
--

CREATE TABLE `mc_customers` (
  `customer_id` int(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `customer_status` int(3) DEFAULT NULL,
  `type_flag` int(3) DEFAULT NULL,
  `firstname` text,
  `lastname` text,
  `phone` varchar(11) NOT NULL,
  `email` varchar(64) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `customer_image` varchar(200) DEFAULT 'img/customers/customer.jpg',
  `timestamp_created` datetime DEFAULT CURRENT_TIMESTAMP,
  `staff` varchar(51) DEFAULT NULL,
  `savings_balance` double DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mc_customers`
--

INSERT INTO `mc_customers` (`customer_id`, `password`, `customer_status`, `type_flag`, `firstname`, `lastname`, `phone`, `email`, `address`, `customer_image`, `timestamp_created`, `staff`, `savings_balance`) VALUES
(1, '467ee2dbe7c93a250754b7fbca5b9fda1ec85fd66a985264dd07481b878dfd8b2', 1, NULL, 'Ixnote', 'Services', '07061325694', 'endee09@gmail.com', 'JD Gomwalk way Jos', 'img/customers/customer.jpg', '2018-01-28 05:24:49', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mc_customer_status`
--

CREATE TABLE `mc_customer_status` (
  `status_id` int(11) NOT NULL,
  `status_name` varchar(30) DEFAULT NULL,
  `status_description` varchar(50) DEFAULT NULL,
  `status_flag` int(1) DEFAULT NULL,
  `timestamp_updated` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `staff` varchar(21) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mc_customer_status`
--

INSERT INTO `mc_customer_status` (`status_id`, `status_name`, `status_description`, `status_flag`, `timestamp_updated`, `staff`) VALUES
(1, 'Saver', 'Owing no loans, having savings', 2, '2017-12-27 07:10:31', ''),
(2, 'Active Loan', 'Owing a Loan, Under Due date', 3, '2017-12-27 07:11:02', ''),
(3, 'Defaulter', 'Owing a Loan, Past Due date', 4, '2017-12-26 21:18:28', ''),
(4, 'Disabled', 'Inactive from system', 5, '2017-12-26 21:18:32', ''),
(5, 'New Client', 'No Savings, No loans', 1, '2017-12-27 07:10:07', '');

-- --------------------------------------------------------

--
-- Table structure for table `mc_customer_types`
--

CREATE TABLE `mc_customer_types` (
  `type_id` int(11) NOT NULL,
  `type_name` varchar(30) DEFAULT NULL,
  `type_description` varchar(50) DEFAULT NULL,
  `type_flag` int(1) DEFAULT NULL,
  `timestamp_updated` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `staff` varchar(21) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mc_customer_types`
--

INSERT INTO `mc_customer_types` (`type_id`, `type_name`, `type_description`, `type_flag`, `timestamp_updated`, `staff`) VALUES
(1, 'Regular', 'Saves, Takes Loans', 1, '2017-12-27 05:04:28', ''),
(2, 'Investor', 'Invests', 2, '2017-12-27 05:04:42', '');

-- --------------------------------------------------------

--
-- Table structure for table `mc_investments`
--

CREATE TABLE `mc_investments` (
  `investment_id` int(11) NOT NULL,
  `investment_status` int(3) DEFAULT NULL,
  `transaction_id` varchar(31) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `investment_date` datetime DEFAULT NULL,
  `investment_amount` double DEFAULT NULL,
  `liquidation_date` datetime DEFAULT NULL,
  `current_value` double DEFAULT NULL,
  `next_update_date` datetime DEFAULT NULL,
  `interest_rate` int(11) DEFAULT NULL,
  `interest_value` double DEFAULT NULL,
  `investment_staff` varchar(21) DEFAULT NULL,
  `liquidation_staff` varchar(21) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mc_investment_status`
--

CREATE TABLE `mc_investment_status` (
  `status_id` int(11) NOT NULL,
  `status_name` varchar(30) NOT NULL,
  `status_flag` int(1) NOT NULL,
  `status_description` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mc_investment_status`
--

INSERT INTO `mc_investment_status` (`status_id`, `status_name`, `status_flag`, `status_description`) VALUES
(1, 'Active', 1, 'Currently running, Not Elapsed'),
(2, 'Liquidated', 2, 'Paid off'),
(3, 'Terminated', 3, 'Currently running, Elapsed');

-- --------------------------------------------------------

--
-- Table structure for table `mc_lgas`
--

CREATE TABLE `mc_lgas` (
  `lga_id` int(11) NOT NULL,
  `lga_name` varchar(21) NOT NULL,
  `state_id` int(11) DEFAULT NULL,
  `timestamp_updated` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mc_loans`
--

CREATE TABLE `mc_loans` (
  `loan_id` int(11) NOT NULL,
  `loan_status` int(3) DEFAULT NULL,
  `transaction_id` varchar(31) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `disburse_date` datetime DEFAULT NULL,
  `disburse_amount` double DEFAULT NULL,
  `loan_profit` double DEFAULT NULL,
  `repayment_date` datetime DEFAULT NULL,
  `repayment_amount` double DEFAULT NULL,
  `disburse_staff` varchar(21) DEFAULT NULL,
  `repayment_staff` varchar(21) DEFAULT NULL,
  `payed_date` datetime DEFAULT NULL,
  `payed_amount` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mc_loan_status`
--

CREATE TABLE `mc_loan_status` (
  `status_id` int(11) NOT NULL,
  `status_name` varchar(30) NOT NULL,
  `status_flag` int(1) NOT NULL,
  `status_description` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mc_loan_status`
--

INSERT INTO `mc_loan_status` (`status_id`, `status_name`, `status_flag`, `status_description`) VALUES
(1, 'Active Loan', 1, 'Currently running, Not Elapsed'),
(2, 'Paid', 2, 'Paid off'),
(3, 'Elapsed', 3, 'Currently running, Elapsed');

-- --------------------------------------------------------

--
-- Table structure for table `mc_logs`
--

CREATE TABLE `mc_logs` (
  `log_id` int(11) NOT NULL,
  `staff` varchar(64) DEFAULT NULL,
  `activity` text NOT NULL,
  `timestamp_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mc_logs`
--

INSERT INTO `mc_logs` (`log_id`, `staff`, `activity`, `timestamp_created`) VALUES
(1, 'Ixnote', 'Ixnote Registered a new customer: Ixnote Services</a>', '2018-01-28 04:24:49');

-- --------------------------------------------------------

--
-- Table structure for table `mc_receipts`
--

CREATE TABLE `mc_receipts` (
  `receipt_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `transaction_id` varchar(31) DEFAULT NULL,
  `transaction_type` varchar(30) NOT NULL,
  `amount` double NOT NULL,
  `staff` varchar(21) DEFAULT NULL,
  `timestamp_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mc_savings`
--

CREATE TABLE `mc_savings` (
  `savings_id` int(11) NOT NULL,
  `transaction_id` varchar(31) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `timestamp_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `staff` varchar(31) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mc_settings_system`
--

CREATE TABLE `mc_settings_system` (
  `company_id` int(6) NOT NULL,
  `company_name` varchar(30) NOT NULL,
  `company_address` varchar(50) NOT NULL,
  `company_phone` varchar(11) NOT NULL,
  `company_website_url` varchar(30) NOT NULL,
  `company_website_name` varchar(30) NOT NULL,
  `timestamp_updated` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `staff` varchar(21) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mc_settings_system`
--

INSERT INTO `mc_settings_system` (`company_id`, `company_name`, `company_address`, `company_phone`, `company_website_url`, `company_website_name`, `timestamp_updated`, `staff`) VALUES
(1, 'Crystale Medical Laboratories', 'No 4 Gomwalk Boulevard, Dogon Karfe, Jos', '08035968690', 'www.ixnoteservices.com', 'Ixnote Services', '2017-12-08 04:30:15', '0');

-- --------------------------------------------------------

--
-- Table structure for table `mc_states`
--

CREATE TABLE `mc_states` (
  `state_id` int(11) NOT NULL,
  `state_name` varchar(21) NOT NULL,
  `timestamp_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mc_withdrawals`
--

CREATE TABLE `mc_withdrawals` (
  `withdrawal_id` int(11) NOT NULL,
  `transaction_id` varchar(31) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `timestamp_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `staff` varchar(21) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `uc_configuration`
--

CREATE TABLE `uc_configuration` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `value` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `uc_configuration`
--

INSERT INTO `uc_configuration` (`id`, `name`, `value`) VALUES
(1, 'website_name', 'NAML'),
(2, 'website_url', 'naml.com.ng/portal/'),
(3, 'email', 'endee09@gmail.com'),
(4, 'activation', 'false'),
(5, 'resend_activation_threshold', '0'),
(6, 'language', 'models/languages/en.php'),
(7, 'template', 'models/site-templates/default.css');

-- --------------------------------------------------------

--
-- Table structure for table `uc_pages`
--

CREATE TABLE `uc_pages` (
  `id` int(11) NOT NULL,
  `page` varchar(150) NOT NULL,
  `private` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uc_pages`
--

INSERT INTO `uc_pages` (`id`, `page`, `private`) VALUES
(4, 'admin_page.php', 1),
(5, 'admin_pages.php', 1),
(6, 'admin_permission.php', 1),
(7, 'admin_permissions.php', 1),
(8, 'admin_user.php', 1),
(9, 'admin_users.php', 1),
(10, 'forgot-password.php', 0),
(11, 'index.php', 0),
(13, 'login.php', 0),
(14, 'logout.php', 1),
(16, 'resend-activation.php', 0),
(17, 'user_settings.php', 1),
(18, 'admin_register.php', 1),
(19, 'dashboard.php', 0),
(20, 'setup.php', 1),
(21, 'customers.php', 1),
(22, 'customer.php', 1),
(23, 'customer_records.php', 1),
(24, 'investments.php', 1),
(25, 'reports.php', 1),
(26, 'script_customeractions.php', 0),
(27, 'script_paymentactions.php', 0),
(28, 'logs.php', 1),
(29, 'script_staffactions.php', 0),
(30, 'customer_register.php', 0);

-- --------------------------------------------------------

--
-- Table structure for table `uc_permissions`
--

CREATE TABLE `uc_permissions` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `uc_permissions`
--

INSERT INTO `uc_permissions` (`id`, `name`) VALUES
(1, 'New Member'),
(2, 'Administrator'),
(3, 'Manager'),
(4, 'Auditor'),
(5, 'Teller');

-- --------------------------------------------------------

--
-- Table structure for table `uc_permission_page_matches`
--

CREATE TABLE `uc_permission_page_matches` (
  `id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uc_permission_page_matches`
--

INSERT INTO `uc_permission_page_matches` (`id`, `permission_id`, `page_id`) VALUES
(2, 1, 14),
(3, 1, 17),
(4, 2, 4),
(5, 2, 5),
(6, 2, 6),
(7, 2, 7),
(8, 2, 8),
(9, 2, 9),
(10, 2, 14),
(11, 2, 17),
(12, 2, 18),
(13, 2, 20),
(14, 2, 21),
(15, 2, 22),
(16, 2, 23),
(17, 2, 24),
(18, 2, 25),
(19, 2, 28),
(20, 3, 8),
(21, 3, 9),
(22, 3, 14),
(23, 3, 17),
(24, 3, 18),
(25, 3, 21),
(26, 3, 22),
(27, 3, 23),
(28, 3, 24),
(29, 3, 25),
(30, 4, 14),
(31, 4, 17),
(32, 4, 21),
(33, 4, 22),
(34, 4, 23),
(35, 4, 24),
(36, 5, 14),
(37, 5, 22),
(38, 5, 23),
(39, 5, 24);

-- --------------------------------------------------------

--
-- Table structure for table `uc_users`
--

CREATE TABLE `uc_users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `display_name` varchar(50) NOT NULL,
  `password` varchar(225) NOT NULL,
  `email` varchar(150) NOT NULL,
  `activation_token` varchar(225) NOT NULL,
  `last_activation_request` int(11) NOT NULL,
  `lost_password_request` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `title` varchar(150) NOT NULL,
  `sign_up_stamp` int(11) NOT NULL,
  `last_sign_in_stamp` int(11) NOT NULL,
  `income_customers` int(11) DEFAULT '0',
  `income_profit` double DEFAULT '0',
  `income_contributions` double DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `uc_users`
--

INSERT INTO `uc_users` (`id`, `user_name`, `display_name`, `password`, `email`, `activation_token`, `last_activation_request`, `lost_password_request`, `active`, `title`, `sign_up_stamp`, `last_sign_in_stamp`, `income_customers`, `income_profit`, `income_contributions`) VALUES
(1, 'admin', 'Ixnote', 'ca7c7d23ab40fbddcc070434a36d8c9f757059c6ae8e8fe9edcc64c46c37a930a', 'endee09@gmail.com', 'fe295c8d0911bf9adbdbe06a4e59ae05', 1514283640, 0, 1, 'Administrator', 1514283640, 1517242288, 1, 0, 0),
(2, 'manager', 'Nasiru Adamu', 'b91aa9c49957f14ebcbaea2ba3ef507dd9637facbcbb58e3cd9a4d5a4610f12f0', 'fidelitynasir@gmail.com', '6374e87190118405ee4cb2da6ffaafac', 1517041244, 0, 1, 'Manager', 1517041244, 1517241263, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `uc_user_permission_matches`
--

CREATE TABLE `uc_user_permission_matches` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `uc_user_permission_matches`
--

INSERT INTO `uc_user_permission_matches` (`id`, `user_id`, `permission_id`) VALUES
(1, 1, 2),
(3, 2, 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mc_activeinvestments`
--
ALTER TABLE `mc_activeinvestments`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `mc_activeloans`
--
ALTER TABLE `mc_activeloans`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `mc_customers`
--
ALTER TABLE `mc_customers`
  ADD PRIMARY KEY (`customer_id`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- Indexes for table `mc_customer_status`
--
ALTER TABLE `mc_customer_status`
  ADD PRIMARY KEY (`status_id`);

--
-- Indexes for table `mc_customer_types`
--
ALTER TABLE `mc_customer_types`
  ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `mc_investments`
--
ALTER TABLE `mc_investments`
  ADD PRIMARY KEY (`investment_id`);

--
-- Indexes for table `mc_investment_status`
--
ALTER TABLE `mc_investment_status`
  ADD PRIMARY KEY (`status_id`);

--
-- Indexes for table `mc_lgas`
--
ALTER TABLE `mc_lgas`
  ADD PRIMARY KEY (`lga_id`);

--
-- Indexes for table `mc_loans`
--
ALTER TABLE `mc_loans`
  ADD PRIMARY KEY (`loan_id`);

--
-- Indexes for table `mc_loan_status`
--
ALTER TABLE `mc_loan_status`
  ADD PRIMARY KEY (`status_id`);

--
-- Indexes for table `mc_logs`
--
ALTER TABLE `mc_logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `mc_receipts`
--
ALTER TABLE `mc_receipts`
  ADD PRIMARY KEY (`receipt_id`);

--
-- Indexes for table `mc_savings`
--
ALTER TABLE `mc_savings`
  ADD PRIMARY KEY (`savings_id`);

--
-- Indexes for table `mc_settings_system`
--
ALTER TABLE `mc_settings_system`
  ADD PRIMARY KEY (`company_id`),
  ADD UNIQUE KEY `company_id` (`company_id`);

--
-- Indexes for table `mc_states`
--
ALTER TABLE `mc_states`
  ADD PRIMARY KEY (`state_id`);

--
-- Indexes for table `mc_withdrawals`
--
ALTER TABLE `mc_withdrawals`
  ADD PRIMARY KEY (`withdrawal_id`);

--
-- Indexes for table `uc_configuration`
--
ALTER TABLE `uc_configuration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uc_pages`
--
ALTER TABLE `uc_pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uc_permissions`
--
ALTER TABLE `uc_permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uc_permission_page_matches`
--
ALTER TABLE `uc_permission_page_matches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uc_users`
--
ALTER TABLE `uc_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uc_user_permission_matches`
--
ALTER TABLE `uc_user_permission_matches`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mc_customers`
--
ALTER TABLE `mc_customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `mc_customer_status`
--
ALTER TABLE `mc_customer_status`
  MODIFY `status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `mc_customer_types`
--
ALTER TABLE `mc_customer_types`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `mc_investments`
--
ALTER TABLE `mc_investments`
  MODIFY `investment_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mc_investment_status`
--
ALTER TABLE `mc_investment_status`
  MODIFY `status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `mc_lgas`
--
ALTER TABLE `mc_lgas`
  MODIFY `lga_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mc_loans`
--
ALTER TABLE `mc_loans`
  MODIFY `loan_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mc_loan_status`
--
ALTER TABLE `mc_loan_status`
  MODIFY `status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `mc_logs`
--
ALTER TABLE `mc_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `mc_receipts`
--
ALTER TABLE `mc_receipts`
  MODIFY `receipt_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mc_savings`
--
ALTER TABLE `mc_savings`
  MODIFY `savings_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mc_settings_system`
--
ALTER TABLE `mc_settings_system`
  MODIFY `company_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `mc_states`
--
ALTER TABLE `mc_states`
  MODIFY `state_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mc_withdrawals`
--
ALTER TABLE `mc_withdrawals`
  MODIFY `withdrawal_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `uc_configuration`
--
ALTER TABLE `uc_configuration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `uc_pages`
--
ALTER TABLE `uc_pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `uc_permissions`
--
ALTER TABLE `uc_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `uc_permission_page_matches`
--
ALTER TABLE `uc_permission_page_matches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `uc_users`
--
ALTER TABLE `uc_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `uc_user_permission_matches`
--
ALTER TABLE `uc_user_permission_matches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
